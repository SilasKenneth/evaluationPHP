$(document).ready(function(){
setTimeout(function(){
  	
  },2000);
  jQuery(".responsive-text").fitText();
  jQuery(".checkbox").iCheck({
          radioClass: 'iradio_square-green',
          checkboxClass: 'icheckbox_square-green',
          increaseArea: '50%'
  });

});